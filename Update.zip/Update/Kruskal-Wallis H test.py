# -*- coding: utf-8 -*-
"""
Created on Tue Dec  3 21:36:46 2024

@author: YU CHENGCHENG
"""

import pandas as pd
import scipy.stats as stats
data = {
    'award_name': [],
    'churn_ratio': []
}

df = pd.DataFrame(data)

grouped = [df[df['award_name'] == award]['churn_ratio'].values for award in df['award_name'].unique()]

h_stat, p_value = stats.kruskal(*grouped)

print(f"Kruskal-Wallis H统计量: {h_stat:.4f}")
print(f"p值: {p_value:.4f}")

if p_value < 0.05:
    print("拒绝零假设，说明不同的award_name在churn_ratio上存在显著差异。")
else:
    print("无法拒绝零假设，说明不同的award_name在churn_ratio上没有显著差异。")

file_path = r"#########.xlsx"

df = pd.read_excel(file_path)


#df = pd.DataFrame(data)
#df['retention_rate'] = df['retention_rate'].str.rstrip('%').astype(float) / 100.0

results = {}


behavior_status_values = df['behavior_status'].unique()

for behavior in behavior_status_values:

    group_data = [df[(df['behavior_status'] == behavior) & (df['award_name'] == award)]['retention_rate'].values
                  for award in df['award_name'].unique()]
    

    h_stat, p_value = stats.kruskal(*group_data)

    results[behavior] = {
        'h_stat': h_stat,
        'p_value': p_value
    }


for behavior, result in results.items():
    print(f"Behavior Status {behavior}:")
    print(f"Kruskal-Wallis H 统计量: {result['h_stat']:.4f}")
    print(f"p值: {result['p_value']:.4f}")
    if result['p_value'] < 0.05:
        print("结果显著，拒绝零假设：不同的award_name对retention_rate有显著影响。\n")
    else:
        print("结果不显著，无法拒绝零假设：不同的award_name对retention_rate没有显著影响。\n")
