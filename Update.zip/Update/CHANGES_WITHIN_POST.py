# -*- coding: utf-8 -*-

import pandas as pd
from scipy import stats
import numpy as np


travel_after_summary = pd.read_csv(r"###########.csv")

earliest_week = travel_after_summary.loc[travel_after_summary.groupby('uid')['week'].idxmin()][['uid', 'week', 'cluster']]
earliest_week = earliest_week.rename(columns={'cluster': 'initial_status'})
travel_after_summary = pd.merge(travel_after_summary, earliest_week[['uid', 'initial_status']], on='uid', how='left')
incentive_period = travel_after_summary[travel_after_summary['week'].isin([39, 40, 41, 42])]
post_incentive_period = travel_after_summary[travel_after_summary['week'].isin([43, 44, 45])]
incentive_avg_frequency = incentive_period.groupby('uid')['travel_frequency'].mean()
post_incentive_avg_frequency = post_incentive_period.groupby('uid')['travel_frequency'].mean()
incentive_avg_bus_ratio = incentive_period.groupby('uid')['bus_ratio'].mean()
post_incentive_avg_bus_ratio = post_incentive_period.groupby('uid')['bus_ratio'].mean()
incentive_avg_metro_ratio = incentive_period.groupby('uid')['metro_ratio'].mean()
post_incentive_avg_metro_ratio = post_incentive_period.groupby('uid')['metro_ratio'].mean()
incentive_avg_entropy = incentive_period.groupby('uid')['entropy'].mean()
post_incentive_avg_entropy = post_incentive_period.groupby('uid')['entropy'].mean()
frequency_comparison = pd.DataFrame({
    'pre_incentive': incentive_avg_frequency,
    'post_incentive': post_incentive_avg_frequency,
    'pre_bus_ratio': incentive_avg_bus_ratio,
    'post_bus_ratio': post_incentive_avg_bus_ratio,
    'pre_metro_ratio': incentive_avg_metro_ratio,
    'post_metro_ratio': post_incentive_avg_metro_ratio,
    'pre_entropy': incentive_avg_entropy,
    'post_entropy': post_incentive_avg_entropy
}).dropna()
def t_test_with_summary(pre_values, post_values, label):

    pre_mean = np.mean(pre_values)
    post_mean = np.mean(post_values)
    pre_std = np.std(pre_values, ddof=1)
    post_std = np.std(post_values, ddof=1)
    

    differences = post_values - pre_values
    diff_mean = np.mean(differences)
    diff_std = np.std(differences, ddof=1)
    diff_se = diff_std / np.sqrt(len(differences)) 
    

    t_stat, p_value = stats.ttest_rel(pre_values, post_values)
    

    ci_lower = diff_mean - 1.96 * diff_se
    ci_upper = diff_mean + 1.96 * diff_se
    

    print(f"{label} 的激励期与激励后期统计结果:")
    print(f"  激励期均值: {pre_mean:.3f}, 标准差: {pre_std:.3f}")
    print(f"  激励后期均值: {post_mean:.3f}, 标准差: {post_std:.3f}")
    print(f"  配对差值均值: {diff_mean:.3f}, 配对差值标准误差: {diff_se:.3f}")
    print(f"  差值95%置信区间: [{ci_lower:.3f}, {ci_upper:.3f}]")
    print(f"  t 值: {t_stat:.3f}, p 值: {p_value:.3f}")
    

    if p_value < 0.05:
        print(f"  显著性：显著变化")
    else:
        print(f"  显著性：没有显著变化")
    print("-" * 50)
    

    return p_value

t_test_results = {}

t_test_results['frequency_p_value'] = t_test_with_summary(frequency_comparison['pre_incentive'], frequency_comparison['post_incentive'], '出行频率')
t_test_results['bus_p_value'] = t_test_with_summary(frequency_comparison['pre_bus_ratio'], frequency_comparison['post_bus_ratio'], '公交占比')
t_test_results['metro_p_value'] = t_test_with_summary(frequency_comparison['pre_metro_ratio'], frequency_comparison['post_metro_ratio'], '地铁占比')
t_test_results['entropy_p_value'] = t_test_with_summary(frequency_comparison['pre_entropy'], frequency_comparison['post_entropy'], '出行规律性（entropy）')
initial_status_groups = travel_after_summary.groupby('initial_status')
for status, group in initial_status_groups:

    incentive_group = group[group['week'].isin([39, 40, 41, 42])]
    post_incentive_group = group[group['week'].isin([43, 44, 45])]
    incentive_avg_frequency = incentive_group.groupby('uid')['travel_frequency'].mean()
    post_incentive_avg_frequency = post_incentive_group.groupby('uid')['travel_frequency'].mean()

    incentive_avg_bus_ratio = incentive_group.groupby('uid')['bus_ratio'].mean()
    post_incentive_avg_bus_ratio = post_incentive_group.groupby('uid')['bus_ratio'].mean()

    incentive_avg_metro_ratio = incentive_group.groupby('uid')['metro_ratio'].mean()
    post_incentive_avg_metro_ratio = post_incentive_group.groupby('uid')['metro_ratio'].mean()

    incentive_avg_entropy = incentive_group.groupby('uid')['entropy'].mean()
    post_incentive_avg_entropy = post_incentive_group.groupby('uid')['entropy'].mean()

    frequency_comparison = pd.DataFrame({
        'pre_incentive': incentive_avg_frequency,
        'post_incentive': post_incentive_avg_frequency,
        'pre_bus_ratio': incentive_avg_bus_ratio,
        'post_bus_ratio': post_incentive_avg_bus_ratio,
        'pre_metro_ratio': incentive_avg_metro_ratio,
        'post_metro_ratio': post_incentive_avg_metro_ratio,
        'pre_entropy': incentive_avg_entropy,
        'post_entropy': post_incentive_avg_entropy
    }).dropna()


    t_test_results[f"{status}_frequency_p_value"] = t_test_with_summary(frequency_comparison['pre_incentive'], frequency_comparison['post_incentive'], f"{status} 状态的出行频率")
    t_test_results[f"{status}_bus_p_value"] = t_test_with_summary(frequency_comparison['pre_bus_ratio'], frequency_comparison['post_bus_ratio'], f"{status} 状态的公交占比")
    t_test_results[f"{status}_metro_p_value"] = t_test_with_summary(frequency_comparison['pre_metro_ratio'], frequency_comparison['post_metro_ratio'], f"{status} 状态的地铁占比")
    t_test_results[f"{status}_entropy_p_value"] = t_test_with_summary(frequency_comparison['pre_entropy'], frequency_comparison['post_entropy'], f"{status} 状态的出行规律性（entropy）")

print("\n所有 initial_status 的配对t检验 p 值：")
for status, p_value in t_test_results.items():
    print(f"{status}: p-value = {p_value:.3f}")

