# -*- coding: utf-8 -*-
import pandas as pd
import matplotlib.pyplot as plt
import scipy.stats as stats
import chardet
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler


travel_before = pd.read_csv(r"#########", encoding='gbk')
travel_after = pd.read_csv(r"#########", encoding='utf-8')
week_card_user = pd.read_csv(r"#########", encoding='ascii')
travel_before['travel_start_time'] = pd.to_datetime(travel_before['travel_start_time'], format='%Y-%m-%d %H:%M:%S', errors='coerce')
travel_before['travel_end_time'] = pd.to_datetime(travel_before['travel_end_time'], format='%Y-%m-%d %H:%M:%S', errors='coerce')
travel_after['travel_start_time'] = pd.to_datetime(travel_after['travel_start_time'], format='%Y-%m-%d %H:%M:%S', errors='coerce')
travel_after['travel_end_time'] = pd.to_datetime(travel_after['travel_end_time'], format='%Y-%m-%d %H:%M:%S', errors='coerce')
cutoff_date = pd.to_datetime('2024-09-19', format='%Y-%m-%d')
before_cutoff = travel_before[travel_before['travel_start_time'] >= cutoff_date]
travel_before = travel_before[travel_before['travel_start_time'] < cutoff_date]
travel_after = pd.concat([travel_after, before_cutoff], ignore_index=True)
earliest_time = travel_after['travel_start_time'].min()
latest_time = travel_after['travel_start_time'].max()
print(f"最早的出行时间: {earliest_time}")
print(f"最晚的出行时间: {latest_time}")
travel_after['week'] = travel_after['travel_start_time'].dt.isocalendar().week
travel_after['year'] = travel_after['travel_start_time'].dt.year
travel_after['day'] = travel_after['travel_start_time'].dt.dayofweek 
frequency = travel_after.groupby(['uid', 'year', 'week']).size().reset_index(name='travel_frequency')
weekly_day_distribution = travel_after.groupby(['uid', 'year', 'week', 'day']).size().reset_index(name='count')
weekly_total_counts = weekly_day_distribution.groupby(['uid', 'year', 'week'])['count'].sum().reset_index(name='total_count')
weekly_day_distribution = weekly_day_distribution.merge(weekly_total_counts, on=['uid', 'year', 'week'], how='left')
weekly_day_distribution['probability'] = weekly_day_distribution['count'] / weekly_day_distribution['total_count']
def entropy_function(group):
    return -np.sum(group['probability'] * np.log2(group['probability'] + 1e-9))
entropy_values = weekly_day_distribution.groupby(['uid', 'year', 'week']).apply(lambda group: entropy_function(group)).reset_index(name='entropy')
bus_trips = travel_after[travel_after['trip_mode'] == 'bus']
bus_ratio = bus_trips.groupby(['uid', 'year', 'week']).size().reset_index(name='bus_count')
metro_trips = travel_after[travel_after['trip_mode'] == 'metro']
metro_ratio = metro_trips.groupby(['uid', 'year', 'week']).size().reset_index(name='metro_count')
combined_stats = frequency.merge(entropy_values, on=['uid', 'year', 'week'], how='left')
combined_stats = combined_stats.merge(bus_ratio, on=['uid', 'year', 'week'], how='left')
combined_stats = combined_stats.merge(metro_ratio, on=['uid', 'year', 'week'], how='left')
combined_stats['bus_count'].fillna(0, inplace=True)
combined_stats['metro_count'].fillna(0, inplace=True)
combined_stats['bus_ratio'] = combined_stats['bus_count'] / combined_stats['travel_frequency']
combined_stats['metro_ratio'] = combined_stats['metro_count'] / combined_stats['travel_frequency']
travel_after_summary = combined_stats[['uid', 'year', 'week', 'travel_frequency', 'entropy', 'bus_ratio', 'metro_ratio']]
travel_after_summary['entropy'] = travel_after_summary['entropy'].apply(lambda x: -x if x < 0 else x)
print(travel_after_summary)
features = travel_after_summary[['travel_frequency', 'entropy', 'bus_ratio', 'metro_ratio']]
scaler = StandardScaler()
scaled_features = scaler.fit_transform(features)
wcss = []  # WCSS: Within-Cluster Sum of Squares
for i in range(1, 11):
    kmeans = KMeans(n_clusters=i, random_state=42)
    kmeans.fit(scaled_features)
    wcss.append(kmeans.inertia_)
plt.figure(figsize=(10, 6))
plt.plot(range(1, 11), wcss, marker='o')
plt.xlabel('Number of clusters')
plt.ylabel('WCSS')
plt.title('Elbow Method to Determine Optimal Number of Clusters')
plt.show()
kmeans = KMeans(n_clusters=********, random_state=42)
travel_after_summary['cluster'] = kmeans.fit_predict(scaled_features)
cluster_summary = travel_after_summary.groupby('cluster').agg({
    'uid': 'count',
    'travel_frequency': 'mean',
    'entropy': 'mean',
    'bus_ratio': 'mean',
    'metro_ratio': 'mean'
}).rename(columns={'uid': 'user_count'})
print(cluster_summary)
earliest_week = travel_after_summary.loc[travel_after_summary.groupby('uid')['week'].idxmin()][['uid', 'week', 'cluster']]
earliest_week = earliest_week.rename(columns={'cluster': 'initial_status'})
retention_trend = earliest_week[['uid', 'initial_status']].copy()
for week in [43, 44, 45]:
    retention_trend[f'week{week}'] = retention_trend['uid'].apply(
        lambda x: 1 if week in travel_after_summary[(travel_after_summary['uid'] == x)]['week'].values else 0
    )
print(retention_trend)
for week in [43, 44, 45]:
    count = retention_trend[f'week{week}'].sum()
    proportion = count / len(retention_trend)
    print(f'Week {week}: count = {count}, proportion = {proportion:.2f}')
initial_status_counts = retention_trend['initial_status'].value_counts()
print("Initial status counts:")
print(initial_status_counts)
for status in initial_status_counts.index:
    filtered_data = retention_trend[retention_trend['initial_status'] == status]
    print(f"Initial status = {status}:")
    for week in [43, 44, 45]:
        count = filtered_data[f'week{week}'].sum()
        proportion = count / len(filtered_data)
        print(f'  Week {week}: count = {count}, proportion = {proportion:.2f}')
output_path = r"##################"
travel_after_summary.to_csv(output_path, index=False)
print(f"文件已成功保存至 {output_path}")
